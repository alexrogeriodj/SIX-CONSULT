package com.ramazan.api.domain;

import lombok.Data;

import java.util.List;

@Data
public class UserData
{
    List<User> data;
}
