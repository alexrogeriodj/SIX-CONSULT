﻿using System;

namespace RazorLight.Internal
{
	[AttributeUsage(AttributeTargets.Property, AllowMultiple = false, Inherited = true)]
	public class RazorInjectAttribute : Attribute
	{

	}
}
