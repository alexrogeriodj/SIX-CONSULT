﻿using System.Threading.Tasks;

namespace RazorLight.Internal
{
	public delegate Task RenderAsyncDelegate();
}
