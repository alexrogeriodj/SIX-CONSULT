﻿using System.Runtime.CompilerServices;

[assembly: InternalsVisibleTo("RazorLight.Tests")]