﻿using System;
using System.Collections.Generic;
using System.Text;

namespace RazorLight.Tests.Models
{
	public class TestViewModel
	{
		public string Title { get; set; }
	}
}
