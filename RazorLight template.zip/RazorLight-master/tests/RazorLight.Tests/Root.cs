﻿using System;
using System.Collections.Generic;
using System.Text;

namespace RazorLight.Tests
{
	public class Root
	{
	}
}
