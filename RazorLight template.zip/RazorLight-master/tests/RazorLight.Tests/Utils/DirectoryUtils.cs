﻿using System.IO;

namespace RazorLight.Tests
{
	public static class DirectoryUtils
	{
		public static string RootDirectory => Directory.GetCurrentDirectory();
	}
}
